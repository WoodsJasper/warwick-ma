Warwick M&A Group - published Instagram research

Q4 2025 | The next wave of biopharma. | 8 slides | 2025-q4-healthcare.pdf
Q4 2025 | Content, compute & consolidation. | 8 slides | 2025-q4-tmt.pdf
Q4 2025 | Reshaping the portfolio. | 12 slides | 2025-q4-industrials-energy.pdf
Q3 2025 | Private capital. Public targets. | 11 slides | 2025-q3-financial-sponsors.pdf
Q3 2025 | Healthcare’s strategic buyers. | 8 slides | 2025-q3-healthcare.pdf
Q3 2025 | Consolidation under pressure. | 13 slides | 2025-q3-industrials-energy.pdf
Q3 2025 | Infrastructure for a digital economy. | 10 slides | 2025-q3-tmt.pdf
November 2024 | November research release. | 2 slides | 2024-11-sector-report-release.pdf
December 2023 | Consolidation in US energy. | 8 slides | 2023-12-energy.pdf
December 2023 | Banks, brokers & financial data. | 10 slides | 2023-12-financial-institutions.pdf
December 2023 | Software & telecoms consolidation. | 8 slides | 2023-12-tmt.pdf
December 2023 | Brands changing hands. | 9 slides | 2023-12-consumer-retail.pdf
December 2023 | Steel & shipping. | 10 slides | 2023-12-industrials.pdf
November 2023 | Banking through uncertainty. | 10 slides | 2023-11-financial-institutions.pdf
November 2023 | Software deals under pressure. | 9 slides | 2023-11-tmt.pdf
November 2023 | Retail brands, new owners. | 8 slides | 2023-11-consumer-retail.pdf
November 2023 | Pipeline acquisitions. | 8 slides | 2023-11-healthcare.pdf
November 2023 | Building scale. | 10 slides | 2023-11-industrials.pdf
October 2022 | Scale in consumer markets. | 8 slides | 2022-10-consumer-retail.pdf
October 2022 | Software remains in focus. | 10 slides | 2022-10-tmt.pdf
October 2022 | Chart’s acquisition of Howden. | 6 slides | 2022-10-industrials.pdf
October 2022 | The energy transition. | 8 slides | 2022-10-energy.pdf
October 2022 | Mortgages & insurance. | 8 slides | 2022-10-financial-institutions.pdf
October 2022 | Digital care & medical technology. | 8 slides | 2022-10-healthcare.pdf
October 2022 | Microsoft & Activision Blizzard. | 6 slides | 2022-10-microsoft-activision-spotlight.pdf
October 2022 | Thoma Bravo & Mercell. | 4 slides | 2022-10-thoma-bravo-mercell-spotlight.pdf
January 2022 | January research release. | 1 slides | 2022-01-sector-report-release.pdf
April 2021 | Renesas & Dialog. | 1 slides | 2021-04-renesas-dialog.pdf
March 2021 | Lucid’s SPAC merger. | 1 slides | 2021-03-lucid-churchill-spac.pdf
